// Get the current URL path up to the last directory
const basePath = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/'));
const apiBase = window.location.origin + basePath + '/api';

export const config = {
    apiUrl: apiBase
};
